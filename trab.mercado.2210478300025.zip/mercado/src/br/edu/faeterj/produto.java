package br.edu.faeterj;

public class produto {
    String nome;
    float valor;
    long qtd;
    String descricao;
    long codBarra;
}
