package br.edu.faeterj;

public class calculadora {
   
	public float Soma (int v1, int v2) {
		
		return v1 + v2;
		
	}
	
	public float Subtrai (int v1, int v2) {
		
		return v1 - v2;
		
	}
	
	public float multiplica (int v1, int v2) {
		
		return v1 * v2;
		
	}
	
	public float divide (int v1, int v2) {
		
		return v1 / v2;
		
	}
	
	public double seno (int v1) {
		
		return java.lang.Math.sin(v1);
	};
	
    public double coseno (int v1) {
		
		return java.lang.Math.cos(v1);
		
	};
	public double raiz (int v1) {
		
		return java.lang.Math.sqrt(v1); 
		
	}
	
	public double decide (int v1, int v2, String op) {
		
		double resultado = 0;
		if (op.equals("+")) {
			
			resultado = Soma(v1,v2);
			
		}else if (op.equals("-")) {
			
			resultado = Subtrai(v1,v2);
			
		}else if (op.equals("*")) {
			
			resultado = multiplica(v1,v2);
			
		}else if (op.equals("/")) {
			
			resultado = divide(v1,v2);
			
		}else if (op.equals("seno")) {
			
			resultado = seno (v1);
			
		}else if (op.equals("coseno")) {
			
			resultado = coseno(v1);
			
		}else if (op.equals("raiz")) {
			
			resultado = raiz(v1);
			
		}
		return resultado;
		
	}
	
}
