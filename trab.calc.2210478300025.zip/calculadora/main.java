package br.edu.faeterj;
import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner sc = new Scanner(System.in);
        int v2 = 0;
        
        System.out.println("digite o valor de v1");
        
        int v1 = sc.nextInt();
        System.out.println("valor de v1: " + v1);
        
        System.out.println("digite o operador do calculo: ");
        
        String op = sc.next();
        
        if (op.equals("+")||op.equals("-")||op.equals("*")||op.equals("/")){
        
        System.out.println("digite o valor de v2");
        
        v2 = sc.nextInt();
        System.out.println("valor de v2: " + v2);
        
        }
        
        calculadora calc = new calculadora();
        
        double resultado = calc.decide(v1, v2, op);
        
        if (op.equals("+")||op.equals("-")||op.equals("*")||op.equals("/")) {
        System.out.println("resultado de v1 " + op + " v2 : " + resultado);
        }else {
        System.out.println("resultado de " + op + "de v1 :" + resultado);
        }
	}

}
